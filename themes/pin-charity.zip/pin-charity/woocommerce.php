<?php get_header(); ?>
<div class="container">
			<div id="skipper">
    		<div class="page_content">
			<?php woocommerce_content(); ?>
		   </div><!-- page_content-->
           </div><!-- skipper -->
    </div><!-- content -->
<?php get_footer(); ?>