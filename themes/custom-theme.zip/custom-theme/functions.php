<?php
    function enqueue_files() {
        wp_enqueue_style('styles', get_stylesheet_uri());
        // wp_enqueue_style('main_styles1', get_template_directory_uri() . "/css/style.css");
        // wp_enqueue_style('main_styles2', get_template_directory_uri() . "/css/bootstrap.min.css");
        // wp_enqueue_style('main_styles3', get_template_directory_uri() . "/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css");
        // wp_enqueue_style('main_styles4', get_template_directory_uri() . "/lib/owlcarousel/assets/owl.carousel.min.css");
        // wp_enqueue_style('main_styles5', get_template_directory_uri() . "/lib/animate/animate.min.css");
//         wp_enqueue_style('font-awesome','https://maxcdn.bootstrapcdn.com/font-awesome/
// 4.7.0/css/font-awesome.min.css');
//         wp_enqueue_style('custom-google-font','https://fonts.googleapis.com/css?
// family=Roboto+Condensed:300,300i,400,400i,700,700i|
// Roboto:100,300,400,400i,700,700i');
    }
    
    add_action('wp_enqueue_scripts', 'enqueue_files');

?>